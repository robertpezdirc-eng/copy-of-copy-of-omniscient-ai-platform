# Slike

Struktura predlaganih map:
- social/
- illustrations/
- infographics/
- stock/

V `infographics/example.svg` je primer vektorske grafike.
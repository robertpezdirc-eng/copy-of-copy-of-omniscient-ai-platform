# White‑label navodila

1. Uredi `config/brand_config.json` (barve, ime, logotip).
2. Zamenjaj `web/assets/img/placeholder.svg` z lastnim logotipom.
3. Uredi meta oznake in vsebino v `web/*.html`.
4. Po potrebi dodaj lastne slike v `slike/` in video v `video/`.
5. Distribucija: uporabi `automation/sync.ps1` za kopijo v `deployment-packages/`.
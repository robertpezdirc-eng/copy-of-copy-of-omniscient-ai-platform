# Poslovni načrt – Predloga

## Povzetek
Kratek opis produkta/storitve, trga in ciljev.

## Trg
Segmenti, velikost, konkurenca.

## Produkt
Funkcionalnosti, vrednost, diferenciranje.

## Marketing
Kanali, sporočila, proračun.

## Finance
Prihodki, stroški, projekcije.
# Račun – Predloga

- Podjetje: 
- Naslov: 
- Kupec: 
- Datum: 
- Postavke: 
- Skupaj:
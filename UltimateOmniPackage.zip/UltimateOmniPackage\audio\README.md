# Audio

Dodajte glasbo in voiceover posnetke v ustrezne mape.
# Getting Started

Dobrodošli! Ta dokument vas vodi skozi prvotno nastavitev paketa.

1. Odprite `web/index.html` v brskalniku.
2. Uredite `config/brand_config.json` za znamčenje.
3. Dodajte blog objave v `docs/blog_posts.json`.
4. Dodajte izdelke v `code/javascript/data/products.json`.
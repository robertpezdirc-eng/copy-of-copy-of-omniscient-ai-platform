# Pogodba – Predloga

Stranki: [A] in [B]

1. Predmet pogodbe
2. Obveznosti strank
3. Ceno in plačilni pogoji
4. Trajanje
5. Podpis
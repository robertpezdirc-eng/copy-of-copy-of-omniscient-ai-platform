def generate_image(prompt: str):
    """Stub: vrne pot do generirane slike (implementiraj integracijo po potrebi)."""
    return {
        "status": "stub",
        "prompt": prompt,
        "path": "../slike/infographics/example.svg"
    }

def generate_video(prompt: str):
    """Stub: vrne pot do generiranega videa (implementiraj integracijo po potrebi)."""
    return {
        "status": "stub",
        "prompt": prompt,
        "path": "../video/promos/"
    }
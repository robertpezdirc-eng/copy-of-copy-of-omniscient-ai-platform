# Video

Mape za:
- animations/
- promos/
- subtitles/

Dodaj svoje datoteke (MP4, MOV, WEBM). V `subtitles/` je primer `.srt`.